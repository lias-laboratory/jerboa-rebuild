(TeX-add-style-hook
 "commands"
 (lambda ()
   (TeX-add-symbols
    '("orbit" 1)))
 :latex)

