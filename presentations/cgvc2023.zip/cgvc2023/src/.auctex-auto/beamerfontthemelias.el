(TeX-add-style-hook
 "beamerfontthemelias"
 (lambda ()
   (TeX-add-to-alist 'LaTeX-provided-package-options
                     '(("fontspec" "no-math")))
   (TeX-run-style-hooks
    "etoolbox"
    "ifxetex"
    "ifluatex"
    "pgfopts"
    "fontspec")
   (TeX-add-symbols
    '("iffontsavailable" 3)
    '("checkfont" 1)
    "x"
    "lias"
    "inserttitle"
    "insertsubtitle"
    "insertsectionhead"
    "insertsubsectionhead")
   (LaTeX-add-counters
    "fontsnotfound"))
 :latex)

