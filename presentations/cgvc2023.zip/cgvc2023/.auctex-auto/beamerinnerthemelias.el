(TeX-add-style-hook
 "beamerinnerthemelias"
 (lambda ()
   (TeX-run-style-hooks
    "etoolbox"
    "keyval"
    "calc"
    "pgfopts"
    "tikz")
   (TeX-add-symbols
    "lias"
    "nologo"
    "maketitle"
    "titlepage"
    "inserttotalframenumber")
   (LaTeX-add-lengths
    "lias"))
 :latex)

